List of names of building block folders in the package and their respective long names

Bb-discussionboard - Discussions
Bb-wiki - Wikis
bb-assessment - Assessments
bb-blogs-journals - Blogs and Journals
bb-grading - Grading
bb-portfolio - Portfolios
bb-selfpeer - Self and Peer Assessment
